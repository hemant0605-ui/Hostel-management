import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import { useApp } from "../context/AppContext";
import { Student } from "../types";
import { motion } from "framer-motion";
import { toast } from "react-toastify";

interface StudentFormProps {
  onClose: () => void;
  studentId?: string | null;
}

const StudentForm: React.FC<StudentFormProps> = ({ onClose, studentId }) => {
  const { students, addStudent, updateStudent } = useApp();
  const editingStudent = studentId ? students.find(s => s.id === studentId) : null;

  const [formData, setFormData] = useState<Partial<Student>>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    gender: "Male",
    address: "",
    course: "",
    SID: "",
    bloodGroup: "A+",
    admissionDate: new Date().toISOString().split("T")[0],
    photoUrl: ""
  });

  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (editingStudent) {
      setFormData(editingStudent);
      setPreview(editingStudent.photoUrl || null);
    }
  }, [editingStudent]);

  // -----------------------------
  // Handle Photo Upload
  // -----------------------------
  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setPreview(base64);
      setFormData(prev => ({ ...prev, photoUrl: base64 }));
    };
    reader.readAsDataURL(file);
  };

  // -----------------------------
  // Submit Form
  // -----------------------------
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone) {
      toast.error("Please fill all required fields!");
      return;
    }

    if (studentId && editingStudent) {
      updateStudent(studentId, formData);
      toast.success("Student updated successfully!");
    } else {
      const newStudent: Student = {
        id: `student-${Date.now()}`,
        ...formData as Student,
        photoUrl: formData.photoUrl || ""
      };

      addStudent(newStudent);
      toast.success("New student added successfully!");
    }

    onClose();
  };

  // -----------------------------
  // Handle Input Change
  // -----------------------------
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-xl shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 rounded-t-xl flex items-center justify-between">
          <h2 className="text-2xl font-bold">
            {studentId ? "Edit Student" : "Add New Student"}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg">
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* FORM */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-grow overflow-hidden">
          <div className="p-6 overflow-y-auto flex-grow">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              {/* Photo Upload */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">Student Photo</label>

                <div className="flex items-center gap-4">
                  {preview ? (
                    <img src={preview} className="w-24 h-24 rounded-full object-cover border" />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                      No Image
                    </div>
                  )}

                  <input type="file" accept="image/*" onChange={handlePhoto} />
                </div>
              </div>

              {/* First Name */}
              <div>
                <label className="text-sm font-medium">First Name *</label>
                <input
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

              {/* Last Name */}
              <div>
                <label className="text-sm font-medium">Last Name *</label>
                <input
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

              {/* Email */}
              <div>
                <label className="text-sm font-medium">Email *</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

              {/* Phone */}
              <div>
                <label className="text-sm font-medium">Phone *</label>
                <input
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

              {/* SID */}
              <div>
                <label className="text-sm font-medium">SID *</label>
                <input
                  name="SID"
                  value={formData.SID}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

              {/* Course */}
              <div>
                <label className="text-sm font-medium">Course *</label>
                <input
                  name="course"
                  value={formData.course}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

              {/* Gender */}
              <div>
                <label className="text-sm font-medium">Gender *</label>
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>

              {/* Blood Group */}
              <div>
                <label className="text-sm font-medium">Blood Group</label>
                <select
                  name="bloodGroup"
                  value={formData.bloodGroup}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg"
                >
                  {["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(bg => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>

              {/* Address */}
              <div className="md:col-span-2">
                <label className="text-sm font-medium">Address *</label>
                <textarea
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>

            </div>
          </div>

          {/* Footer */}
          <div className="p-6 border-t flex justify-end gap-4">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 border rounded-lg"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700"
            >
              {studentId ? "Update Student" : "Add Student"}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default StudentForm;
