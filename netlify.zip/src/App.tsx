// src/App.tsx
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Pages
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import Rooms from "./pages/Rooms";
import Login from "./pages/Login";
import IDCards from "./pages/IDCards";

// Context
import { AppProvider } from "./context/AppContext";

// Navbar or Layout (if exists)
import Navbar from "./components/Navbar";

// Toastify
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
          {/* Navbar */}
          <Navbar />

          {/* App Routes */}
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/students" element={<Students />} />
            <Route path="/rooms" element={<Rooms />} />
            <Route path="/login" element={<Login />} />
            <Route path="/id-cards" element={<IDCards />} />
          </Routes>
        </div>

        {/* ⭐ Toast Notifications */}
        <ToastContainer
          position="top-right"
          autoClose={2500}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          pauseOnHover
          draggable
          theme="colored"
        />
      </BrowserRouter>
    </AppProvider>
  );
}

export default App;
