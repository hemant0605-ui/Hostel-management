import React, { useState } from "react";
import { Search } from "lucide-react";
import { useApp } from "../context/AppContext";
import { motion } from "framer-motion";

const IDCards: React.FC = () => {
  const { students } = useApp();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredStudents = students.filter((student) =>
    `${student.firstName} ${student.lastName}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase()) ||
    (student.SID || "").toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition">
      <div className="container mx-auto px-4 py-8">
        
        {/* Page Title */}
        <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          ID Cards
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Premium Student ID Cards
        </p>

        {/* Search Bar */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name or SID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 dark:text-white"
            />
          </div>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredStudents.map((student, index) => {
            const admissionDate = new Date(student.admissionDate);
            const expiryDate = new Date(
              admissionDate.setFullYear(admissionDate.getFullYear() + 4)
            ).toLocaleDateString("en-GB");

            return (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="relative"
              >
                {/* Card */}
                <div className="w-[300px] h-[480px] rounded-2xl shadow-xl bg-white overflow-hidden relative">
                  
                  {/* PURPLE TOP */}
                  <div className="absolute inset-0">
                    <div className="w-full h-[55%] bg-[#4B2EFF] rounded-b-[45%]" />

                    {/* GOLD WAVE */}
                    <div className="absolute top-[38%] left-0 w-full h-16 bg-gradient-to-r from-orange-400 to-yellow-300 rotate-[-5deg]" />
                  </div>

                  {/* CONTENT */}
                  <div className="absolute inset-0 p-5 z-10 flex flex-col">

                    {/* Name + Photo */}
                    <div className="flex justify-between items-start">
                      <div>
                        <h2 className="text-white font-bold text-2xl leading-6">
                          {student.firstName}
                        </h2>
                        <h3 className="text-white text-xl opacity-90 font-semibold">
                          {student.lastName}
                        </h3>
                      </div>

                      {/* ROUND PROFILE PHOTO */}
                      <div className="w-[95px] h-[95px] rounded-full border-4 border-white shadow-lg overflow-hidden bg-white">
                        <img
                          src={student.photoUrl}
                          alt="photo"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>

                    {/* University Name */}
                    <h3 className="text-yellow-300 font-bold text-sm tracking-wide mt-3">
                      SURESH GYAN VIHAR UNIVERSITY
                    </h3>

                    {/* DETAILS */}
                    <div className="mt-auto bg-white rounded-xl shadow-inner p-4 space-y-2 text-sm">

                      <p className="text-gray-700 font-semibold">
                        SID: <span className="font-bold">{student.SID}</span>
                      </p>

                      <p className="text-gray-700 font-semibold">
                        Course: <span className="font-bold">{student.course}</span>
                      </p>

                      <p className="text-gray-700 font-semibold">
                        Phone: <span className="font-bold">{student.phone}</span>
                      </p>

                      <p className="text-gray-700 font-semibold">
                        Email: <span className="font-bold">{student.email}</span>
                      </p>

                      <p className="text-gray-700 font-semibold">
                        Blood Group: <span className="font-bold">{student.bloodGroup}</span>
                      </p>

                      <p className="text-gray-700 font-semibold">
                        Expiry Date: <span className="font-bold">{expiryDate}</span>
                      </p>

                    </div>

                  </div>

                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredStudents.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-300">
            No students found
          </div>
        )}

      </div>
    </div>
  );
};

export default IDCards;
