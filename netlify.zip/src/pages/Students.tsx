// src/pages/Students.tsx
import React, { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { UserPlus, Trash2, Edit3, Search } from "lucide-react";
import { useApp } from "../context/AppContext";
import StudentForm from "../components/StudentForm";
import { toast } from "react-toastify";

const InfoCard: React.FC<{ title: string; value: number; accent?: string }> = ({
  title,
  value,
  accent
}) => {
  const accentClass = accent || "from-indigo-500 to-indigo-600";
  return (
    <div className={`bg-gradient-to-r ${accentClass} text-white rounded-2xl p-5 shadow-md`}>
      <div className="text-sm opacity-90">{title}</div>
      <div className="text-2xl font-bold mt-2">{value}</div>
    </div>
  );
};

const Students: React.FC = () => {
  const { students, deleteStudent } = useApp();

  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  const [searchTerm, setSearchTerm] = useState("");

  const totalStudents = students.length;
  const maleCount = students.filter((s) => (s.gender || "").toLowerCase() === "male").length;
  const femaleCount = students.filter((s) => (s.gender || "").toLowerCase() === "female").length;
  const roomsAssigned = students.filter((s) => s.roomId && s.roomId.trim() !== "").length;

  // Search with SID support
  const filteredStudents = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return students;
    return students.filter((student) => {
      const name = `${student.firstName} ${student.lastName}`.toLowerCase();
      return (
        name.includes(q) ||
        (student.SID || "").toLowerCase().includes(q) ||
        (student.rollNumber || "").toLowerCase().includes(q) ||
        (student.email || "").toLowerCase().includes(q)
      );
    });
  }, [students, searchTerm]);

  // Delete function with toast
  const handleDelete = (id: string) => {
    deleteStudent(id);
    toast.success("Student deleted successfully!");
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="container mx-auto px-4 py-8">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
          <div>
            <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-100 mb-2">
              Students
            </h1>
            <p className="text-gray-600 dark:text-gray-300">Manage all hostel students efficiently</p>
          </div>

          <button
            onClick={() => {
              setEditId(null);
              setShowForm(true);
            }}
            className="bg-indigo-600 text-white px-5 py-2 rounded-xl flex items-center gap-2 shadow-md hover:bg-indigo-700 transition"
          >
            <UserPlus className="h-5 w-5" />
            Add Student
          </button>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <InfoCard title="Total Students" value={totalStudents} />
          <InfoCard title="Male Students" value={maleCount} accent="from-blue-500 to-blue-600" />
          <InfoCard title="Female Students" value={femaleCount} accent="from-pink-500 to-rose-500" />
          <InfoCard title="Rooms Assigned" value={roomsAssigned} accent="from-green-500 to-emerald-500" />
        </div>

        {/* Search Bar */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-6 border border-gray-200 dark:border-gray-700">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, SID, roll number, or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Students Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-7">
          {filteredStudents.map((student, index) => (
            <motion.div
              key={student.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.04 }}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-md hover:shadow-xl p-6 border border-gray-100 dark:border-gray-700"
            >
              {/* Photo */}
              <div className="flex justify-center">
                {student.photoUrl ? (
                  <img
                    src={student.photoUrl}
                    className="w-24 h-24 rounded-full border object-cover shadow-sm"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
                    No Image
                  </div>
                )}
              </div>

              <h2 className="text-xl font-semibold text-center mt-4 text-gray-800 dark:text-gray-100">
                {student.firstName} {student.lastName}
              </h2>

              {/* Details */}
              <div className="text-gray-600 dark:text-gray-300 text-sm mt-4 space-y-1 text-center">
                <p><span className="font-semibold">SID:</span> {student.SID}</p>
                <p><span className="font-semibold">Email:</span> {student.email}</p>
                <p><span className="font-semibold">Phone:</span> {student.phone}</p>
                <p><span className="font-semibold">Course:</span> {student.course}</p>
                <p><span className="font-semibold">Year:</span> {student.year}</p>
                <p><span className="font-semibold">Roll No:</span> {student.rollNumber}</p>
                <p><span className="font-semibold">Room:</span> {student.roomId || "Not Assigned"}</p>
              </div>

              {/* Buttons */}
              <div className="flex justify-between mt-6 pt-3 border-t border-gray-200 dark:border-gray-700">
                {/* Edit */}
                <button
                  onClick={() => {
                    setEditId(student.id);
                    setShowForm(true);
                  }}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  <Edit3 className="h-4 w-4 inline-block mr-1" />
                  Edit
                </button>

                {/* Delete */}
                <button
                  onClick={() => handleDelete(student.id)}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                >
                  <Trash2 className="h-4 w-4 inline-block mr-1" />
                  Delete
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredStudents.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-300">
            No students found
          </div>
        )}
      </div>

      {showForm && (
        <StudentForm studentId={editId} onClose={() => setShowForm(false)} />
      )}
    </div>
  );
};

export default Students;
